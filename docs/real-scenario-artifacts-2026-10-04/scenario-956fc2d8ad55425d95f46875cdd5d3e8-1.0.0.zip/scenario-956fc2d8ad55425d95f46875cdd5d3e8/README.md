# 服务申请分流插件

## 用途

本插件实现服务申请完整性检查与紧急分流工作流，对服务申请记录进行结构化校验，根据 priority 字段将申请分配至加急（expedited）或常规（standard）通道，输出可追溯的分流结论与理由。

## Claude Code 安装与依赖

```bash
# 安装依赖
python -m pip install -r requirements.txt

# 验证插件结构
claude plugin validate ./scenario-956fc2d8ad55425d95f46875cdd5d3e8

# 启动插件
claude --plugin-dir ./scenario-956fc2d8ad55425d95f46875cdd5d3e8
```

## 环境配置

| 变量 | 说明 |
|------|------|
| SCENARIO_API_KEY | 绑定到本业务场景的凭证，作用域需包含 capabilities:read 和 capabilities:invoke |
| SCENARIO_MCP_URL | 平台 HTTPS MCP 端点地址 |

## 输入字段

| 字段名 | 类型 | 说明 | 必填 |
|--------|------|------|------|
| entity_service_request_request_id | string | 申请单编号 | 是 |
| entity_service_request_title | string | 申请标题 | 是 |
| entity_service_request_description | string | 申请描述 | 是 |
| entity_service_request_applicant_id | string | 申请人ID | 是 |
| entity_service_request_service_type_id | string | 服务类型ID | 是 |
| entity_service_request_priority | enum(low/normal/high) | 优先级 | 是 |

## 分流规则

| Priority | 通道 | 说明 |
|-----------|------|------|
| high | expedited | 加急通道，优先处理 |
| low / normal | standard | 常规通道，标准排队 |

## 校验约束

以下情况工作流不产出有效分流结果：

- 缺少 `entity_service_request_applicant_id`
- `entity_service_request_priority` 不在枚举值 low/normal/high 范围内

补齐缺失字段后，需使用新的调用身份重新发起请求。

## 异步回执轮询

1. 调用 `invoke_scenario_capability` 后获取 invocation_id
2. 使用 `get_scenario_receipt` 查询执行状态
3. 轮询直至状态为终态（succeeded/failed）
4. 报告排队中、待审批或失败信息

## 发布与停用

- 插件版本绑定到 release_id: 956fc2d8ad55425d95f46875cdd5d3e8
- 发布停用时报告并请求新版插件
- 不得切换至草稿或未发布版本

## 安全配置

- API 密钥不得写入聊天或包文件
- 仅使用 HTTPS 端点
- 凭证作用域遵循最小权限原则

## 运行示例与结果核对

在插件根目录运行 `python -m examples.invoke`。示例只发起一次完整合成输入并显示首次回执；首次返回可能仍为排队，不能据此宣称分流完成。安装宿主随后使用 `get_scenario_receipt` 按原 invocation_id 查询到工作流终态，核对输出中的 `request_id`、`route`、`reason`。本场景不输出 `channel` 或业务 `evidence` 字段。失败必须展示实际错误，不输出分流结论。

在 `inputs.record` 内按发现契约的字段名提交用户本次输入，不从历史补值。缺失或非法字段请先向用户明确说明；正式有效性仍由平台服务端裁决。

本包通过 MCP 调用平台能力，依赖在线平台与有效的场景凭据；它不包含离线业务执行内核。下载 Marketplace 发布包后，可先在本地注册其目录并安装，或人工将材料发布到受权 Git 仓库后向第三方分发安装地址。
