---
name: run-scenario
description: 调用服务申请分流工作流，执行完整性检查与紧急分流。
---

## 读取场景契约

读取 ${CLAUDE_PLUGIN_ROOT}/references/scenario.json 获取场景定义，包含工作流 ID: 7e3711f7d9cb4051bbb39af3d2e06b61、发布版本 956fc2d8ad55425d95f46875cdd5d3e8、定义哈希 830a447e29b1393610b446fcc821f4b3423ba7fbde6d2d1df4aa3cb2a7731ae7。

## 发现能力

使用 list_scenario_capabilities 发现能力及其输入 schema，确认 entity_service_request_priority 的枚举值为 low/normal/high。

## 收集业务输入

向用户收集六个字段的实际值：

1. entity_service_request_request_id（申请单编号）
2. entity_service_request_title（申请标题）
3. entity_service_request_description（申请描述）
4. entity_service_request_applicant_id（申请人ID）
5. entity_service_request_service_type_id（服务类型ID）
6. entity_service_request_priority（优先级：low/normal/high）

建模文档和历史对话不属于运行时数据，需直接询问用户。

## 前置校验

校验以下条件，任一不满足则不调用工作流：

- entity_service_request_applicant_id 不得为空
- entity_service_request_priority 必须在 low/normal/high 范围内

若字段缺失或非法，返回具体错误信息，要求用户补正。

## 调用工作流

使用 invoke_scenario_capability('workflow', '7e3711f7d9cb4051bbb39af3d2e06b61', {'record': input_record}) 发起调用。固定使用场景契约中的 capability_key、release_id 和 definition_hash。

记录返回的 invocation_id 用于后续回执查询。

## 查询回执

使用 get_scenario_receipt 查询执行状态：

- 状态为 queued 或 running：报告待处理，继续轮询
- 状态为 awaiting_approval：使用 read_scenario_approval 读取指令，呈现给用户
- 用户明确回复后，使用 reply_scenario_interaction 提供修订和管理证据
- 状态为 succeeded/failed：工作流完成，输出结论

## 分流结果解读

工作流输出包含：

- request_id：本次申请编号
- route：expedited（high）或 standard（low/normal）
- reason：分流理由
- 不编造 channel/evidence 等契约未声明字段；审计证据保留在真实回执中

## 交付与终止

只有在获取到 succeeded 状态的回执后，才向用户交付最终结果。

报告发布停用信息并请求新版插件；不切换至草稿或未发布版本。

## 幂等处理

查询同一执行时复用原 invocation_id；重试同一业务调用时复用原 idempotency_key。补充或变更输入属于新调用，使用新的调用身份，不盲目重放不确定的效果。