import asyncio
import json
from server import invoke_scenario_capability


async def main():
    result = await invoke_scenario_capability(
        'workflow',
        '7e3711f7d9cb4051bbb39af3d2e06b61',
        {
            'record': {
                'entity_service_request_request_id': 'PLUGIN-SYNTHETIC-001',
                'entity_service_request_title': '合成服务申请',
                'entity_service_request_description': '本示例仅演示完整的合成业务输入。',
                'entity_service_request_applicant_id': 'APP-001',
                'entity_service_request_service_type_id': 'ST-SYNTHETIC',
                'entity_service_request_priority': 'normal'
            }
        }
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    asyncio.run(main())