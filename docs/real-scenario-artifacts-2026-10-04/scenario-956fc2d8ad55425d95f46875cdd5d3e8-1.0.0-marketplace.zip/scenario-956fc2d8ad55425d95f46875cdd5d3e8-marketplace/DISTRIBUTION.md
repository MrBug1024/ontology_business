# 自托管插件发布材料

插件：scenario-956fc2d8ad55425d95f46875cdd5d3e8；版本：1.0.0。本包尚未上传到任何外部仓库。

1. 解压后验证：`claude plugin validate ./scenario-956fc2d8ad55425d95f46875cdd5d3e8-marketplace`。
2. 本地安装：`claude plugin marketplace add ./scenario-956fc2d8ad55425d95f46875cdd5d3e8-marketplace`，然后 `claude plugin install scenario-956fc2d8ad55425d95f46875cdd5d3e8@scenario-956fc2d8ad55425d95f46875cdd5d3e8-marketplace`。
3. Git 自托管：将市场目录内容放入你有权发布的仓库根目录；第三方使用 `claude plugin marketplace add <你的仓库地址>` 注册，再使用上述 install 命令。
4. 私有仓库由第三方自行取得仓库读取权限；业务调用另行配置其场景专属凭据。
5. 更新必须重新验证业务发布与代码，使用新插件版本并更新市场条目；不得覆盖旧发布身份。
插件停用和权限仍由原平台裁决。市场安装成功不代表业务调用已验收。
